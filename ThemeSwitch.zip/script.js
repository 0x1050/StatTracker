<button>Switch color "Click me"</button>

 <script type="text/javascript">

 var color = ["#e74c3c","#3498db","#2ecc71","#95a5a6","#f1c40f","#e74c3c"];

 var i = 0;

 document.querySelector("button").addEventListener("click",function()
 {
 
  i=i < color.length ? ++i :0;

  document.querySelector("body").style.background = color[i]

  })

</script>